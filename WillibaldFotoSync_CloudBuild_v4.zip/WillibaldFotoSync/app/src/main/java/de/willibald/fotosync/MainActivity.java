package de.willibald.fotosync;

import android.Manifest;
import android.app.Activity;
import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final int PICK_FOLDER = 4, ASK_IMAGES = 5, JOB_ID = 16011;
    private TextView status;
    private SharedPreferences prefs;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("sync", MODE_PRIVATE);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL); root.setPadding(32, 48, 32, 32);
        TextView title = new TextView(this); title.setText("Willibald FotoSync"); title.setTextSize(25); root.addView(title);
        status = new TextView(this); status.setTextSize(16); root.addView(status);
        add(root, "Zielordner freigeben", v -> {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            startActivityForResult(intent, PICK_FOLDER);
        });
        add(root, "Jetzt abgleichen", v -> sync());
        setContentView(root);
        status.setText(prefs.getString("last_report", "Bitte Zielordner freigeben. Cloud-Ordner nur bei Android-Unterstützung."));
        if (prefs.contains("folder")) { schedule(); sync(); }
    }
    private void add(LinearLayout root, String title, View.OnClickListener click) {
        Button b = new Button(this); b.setText(title); b.setOnClickListener(click); root.addView(b);
    }
    @Override protected void onActivityResult(int code, int result, Intent data) {
        super.onActivityResult(code, result, data);
        if (code == PICK_FOLDER && result == RESULT_OK && data != null && data.getData() != null) {
            Uri tree = data.getData();
            try {
                getContentResolver().takePersistableUriPermission(tree, Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                prefs.edit().putString("folder", tree.toString()).apply();
                schedule(); sync();
            } catch (Exception e) { status.setText("Ordnerfreigabe fehlgeschlagen: " + e.getMessage()); }
        } else if (code == ASK_IMAGES && result == RESULT_OK) sync();
    }
    private void schedule() {
        JobScheduler jobs = (JobScheduler) getSystemService(Context.JOB_SCHEDULER_SERVICE);
        JobInfo job = new JobInfo.Builder(JOB_ID, new ComponentName(this, SyncJob.class))
                .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                .setPersisted(true)
                .setPeriodic(60 * 60 * 1000L)
                .build();
        int result = jobs.schedule(job);
        if (result != JobScheduler.RESULT_SUCCESS) status.setText("Hintergrundabgleich konnte nicht geplant werden.");
    }
    private void sync() {
        if (!prefs.contains("folder")) { status.setText("Zuerst Zielordner wählen."); return; }
        String permission = Build.VERSION.SDK_INT >= 33 ? Manifest.permission.READ_MEDIA_IMAGES : Manifest.permission.READ_EXTERNAL_STORAGE;
        if (checkSelfPermission(permission) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{permission}, ASK_IMAGES); return;
        }
        if (Build.VERSION.SDK_INT >= 34 && checkSelfPermission(Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED) == PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.READ_MEDIA_IMAGES) != PackageManager.PERMISSION_GRANTED) {
            status.setText("Nur ausgewählte Fotos freigegeben. Bitte in Android-Einstellungen alle Fotos erlauben."); return;
        }
        status.setText("Prüfe neue Fotos...");
        new Thread(() -> {
            String report = PhotoSync.run(getApplicationContext());
            prefs.edit().putString("last_report", report).putLong("last_run", System.currentTimeMillis()).apply();
            runOnUiThread(() -> status.setText(report));
        }).start();
    }
}

package de.willibald.fotosync;

import android.Manifest;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.MessageDigest;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

public final class PhotoSync {
    public static final long START_MS = 1794787200000L; // 2026-11-16 00:00 UTC
    public static String run(Context ctx) {
        SharedPreferences prefs = ctx.getSharedPreferences("sync", Context.MODE_PRIVATE);
        String saved = prefs.getString("folder", null);
        if (saved == null) return "Bitte zuerst einen Zielordner auswählen.";
        String permission = Build.VERSION.SDK_INT >= 33 ? Manifest.permission.READ_MEDIA_IMAGES : Manifest.permission.READ_EXTERNAL_STORAGE;
        if (ctx.checkSelfPermission(permission) != PackageManager.PERMISSION_GRANTED) return "Fotozugriff fehlt. Bitte App öffnen und Berechtigung erteilen.";
        ContentResolver resolver = ctx.getContentResolver();
        Uri tree = Uri.parse(saved);
        Uri parent;
        try { parent = DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree)); }
        catch (Exception e) { return "Zielordner nicht mehr verfügbar. Bitte erneut auswählen."; }
        Set<String> known = new HashSet<>(prefs.getStringSet("hashes", new HashSet<>()));
        int copied = 0, duplicates = 0, errors = 0;
        try (Cursor c = resolver.query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                new String[]{MediaStore.Images.Media._ID, MediaStore.Images.Media.DATE_TAKEN, MediaStore.Images.Media.DISPLAY_NAME, MediaStore.Images.Media.MIME_TYPE},
                MediaStore.Images.Media.DATE_TAKEN + ">=?", new String[]{Long.toString(START_MS)}, MediaStore.Images.Media.DATE_TAKEN + " ASC")) {
            if (c == null) return "Medienbibliothek nicht verfügbar.";
            while (c.moveToNext()) {
                Uri photo = ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, c.getLong(0));
                Uri output = null;
                try {
                    String hash = hash(resolver, photo);
                    if (known.contains(hash)) { duplicates++; continue; }
                    String original = c.getString(2);
                    String mime = c.getString(3);
                    if (mime == null || !mime.startsWith("image/")) mime = "application/octet-stream";
                    String safe = (original == null ? "foto" : original).replaceAll("[^a-zA-Z0-9._-]", "_");
                    output = DocumentsContract.createDocument(resolver, parent, mime, hash.substring(0, 16) + "_" + safe);
                    if (output == null) throw new Exception("Ordner nicht beschreibbar");
                    try (InputStream in = resolver.openInputStream(photo); OutputStream out = resolver.openOutputStream(output, "w")) {
                        if (in == null || out == null) throw new Exception("Stream fehlt");
                        byte[] buffer = new byte[65536]; int n;
                        while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
                        out.flush();
                    }
                    known.add(hash);
                    prefs.edit().putStringSet("hashes", new HashSet<>(known)).commit();
                    copied++;
                } catch (Exception ex) {
                    errors++;
                    if (output != null) try { DocumentsContract.deleteDocument(resolver, output); } catch (Exception ignored) {}
                }
            }
        } catch (Exception ex) { return "Abgleich fehlgeschlagen: " + ex.getMessage(); }
        return "Abgleich: " + copied + " neu, " + duplicates + " bekannt, " + errors + " Fehler. Keine automatische Baustellen-Erkennung.";
    }
    private static String hash(ContentResolver r, Uri photo) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        try (InputStream in = r.openInputStream(photo)) {
            if (in == null) throw new Exception("Foto nicht lesbar");
            byte[] b = new byte[65536]; int n;
            while ((n = in.read(b)) != -1) md.update(b, 0, n);
        }
        StringBuilder s = new StringBuilder();
        for (byte b : md.digest()) s.append(String.format(Locale.ROOT, "%02x", b & 255));
        return s.toString();
    }
}

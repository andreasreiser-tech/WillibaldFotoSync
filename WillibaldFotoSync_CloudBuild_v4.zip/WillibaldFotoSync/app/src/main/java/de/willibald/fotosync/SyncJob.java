package de.willibald.fotosync;

import android.app.job.JobParameters;
import android.app.job.JobService;
import android.content.Context;
import android.content.SharedPreferences;

public class SyncJob extends JobService {
    @Override public boolean onStartJob(JobParameters params) {
        new Thread(() -> {
            String report = PhotoSync.run(getApplicationContext());
            SharedPreferences p = getSharedPreferences("sync", Context.MODE_PRIVATE);
            p.edit().putString("last_report", report).putLong("last_run", System.currentTimeMillis()).apply();
            jobFinished(params, false);
        }).start();
        return true;
    }
    @Override public boolean onStopJob(JobParameters params) { return true; }
}

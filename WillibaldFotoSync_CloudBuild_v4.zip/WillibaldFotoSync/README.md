# Willibald FotoSync – Android Studio source project

## Implemented in source
- Scans Android MediaStore photos captured from 2026-11-16 00:00 UTC.
- SHA-256 deduplication across successful transfers on this installation.
- On-demand and on-app-open scan.
- Android JobScheduler periodic background attempt every ~1 hour (Android may delay, throttle, or skip it; not a guaranteed hourly schedule). Network required for the background job; Wi-Fi or mobile data permitted.
- Writes to a user-granted Android Storage Access Framework document tree. Failed partial copies are removed where possible.
- Keeps original photos untouched and remembers last result.

## Important limitations
- **Not a direct Google Drive API integration**. Google Drive's Android app may not offer a writable document tree; if it does not, the Drive target will not work. A Google OAuth implementation with Drive API is needed for reliable Drive uploading.
- **No GPS/image-content construction-site classifier**, ambiguous assignment UI, or ChatGPT Library/Projects automatic ingestion. Those need further implementation and a suitable authorized AI/cloud integration.
- Android 14+ requires granting **all photos** (not selected photos) for whole-gallery scanning.
- SHA-256 deduplication is local; reinstalling or clearing app data resets it. There is no remote duplicate audit.
- Android SDK/Gradle build tools are unavailable in this environment; this ZIP contains source, **not an installable APK** and is not device-tested.

## Build
Open in Android Studio with JDK 17, install Android SDK 35 and Gradle 8.7+ compatible with Android Gradle Plugin 8.6.1, sync Gradle, then Build APK. The target Android version is 14/15. Confirm Android 14 media access and folder provider support on your device.

## Security
No developer-operated server or embedded credentials. The app only writes to the folder you explicitly authorize. Do not grant access to confidential company photos without employer approval.

## Version 3 corrections
- Reports failure to schedule the Android periodic job.
- Detects limited-photo permissions on Android 14 and prompts the user to grant all-photo access.
- Handles a revoked or invalid document-tree URI more gracefully.
- This remains a source project, not a finished APK; Google OAuth, AI site recognition, and automatic ChatGPT import are not implemented.

## Cloud-Build ohne lokalen PC (Version 4)
A GitHub Actions workflow is included at `.github/workflows/android-apk.yml`.
To build: create a private GitHub repository, upload the **contents** of this project to the repository root (including the hidden `.github` directory), open Actions > Android APK bauen > Run workflow, then download the `WillibaldFotoSync-debug-apk` artifact. This needs a GitHub account and repository permissions; the workflow has **not** been run or verified here. The debug APK is for testing, not Play Store release.

This build pipeline does NOT implement Google Drive OAuth, automatic image-based site recognition, or ChatGPT ingestion. Do not mistake the generated APK for the fully requested automation.
